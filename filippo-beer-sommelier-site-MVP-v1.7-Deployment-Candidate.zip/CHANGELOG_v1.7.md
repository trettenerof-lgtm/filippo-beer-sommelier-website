# MVP v1.7 Deployment Candidate

Date: 2026-08-01

- Integrated the approved Brevo responsive iframe on every newsletter entry point.
- Set the public contact email to `info@filippobeersommelier.it`.
- Updated privacy, cookie and provider documentation for OVHcloud and Brevo.
- Documented retention: newsletter until withdrawal with 24-month inactivity review; leads 12 months; correction reports 24 months.
- Confirmed double opt-in and welcome-guide automation as active and tested.
- Disabled booking and payment forms for the initial launch; requests are routed to email.
- Removed obsolete hosting-platform form configuration and deployment files.
- Updated the web manifest and release documentation.
- Performed static internal-link, placeholder, archive-integrity and responsive iframe preflight.

#!/usr/bin/env python3
from pathlib import Path
from bs4 import BeautifulSoup
import json, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
issues=[]; pages=[]
for f in root.rglob('*.html'):
    rel='/' if f==root/'index.html' else '/'+str(f.parent.relative_to(root)).replace('\\','/')+'/' if f.name=='index.html' else '/'+str(f.relative_to(root)).replace('\\','/')
    soup=BeautifulSoup(f.read_text(encoding='utf-8'),'html.parser')
    title=soup.title.get_text(strip=True) if soup.title else ''
    desc=soup.find('meta',attrs={'name':'description'})
    robots=soup.find('meta',attrs={'name':'robots'})
    indexable=not (robots and 'noindex' in robots.get('content',''))
    h1=soup.find_all('h1'); canon=soup.find('link',rel='canonical')
    if not title: issues.append([rel,'missing title'])
    if indexable and not desc: issues.append([rel,'missing meta description'])
    if indexable and len(h1)!=1: issues.append([rel,f'h1 count {len(h1)}'])
    if indexable and not canon: issues.append([rel,'missing canonical'])
    if indexable and not soup.find('meta',property='og:title'): issues.append([rel,'missing og:title'])
    for img in soup.find_all('img'):
        if not img.get('alt'): issues.append([rel,'image missing alt'])
    for s in soup.find_all('script',attrs={'type':'application/ld+json'}):
        try: json.loads(s.string or '')
        except Exception as e: issues.append([rel,'invalid JSON-LD'])
    pages.append({'path':rel,'title':title,'indexable':indexable,'h1_count':len(h1)})
print(json.dumps({'pages':pages,'issues':issues,'status':'PASS' if not issues else 'FAIL'},ensure_ascii=False,indent=2))

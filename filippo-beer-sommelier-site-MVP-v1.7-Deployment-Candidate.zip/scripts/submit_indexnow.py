#!/usr/bin/env python3
from pathlib import Path
import json, sys, urllib.request
if len(sys.argv)!=3:
    raise SystemExit('Usage: submit_indexnow.py <domain> <key>')
domain=sys.argv[1].replace('https://','').replace('http://','').strip('/')
key=sys.argv[2]
site=Path(__file__).resolve().parents[1]
urls=[]
for p in site.rglob('index.html'):
    rel=p.parent.relative_to(site).as_posix()
    url=f'https://{domain}/' if rel=='.' else f'https://{domain}/{rel}/'
    urls.append(url)
payload={'host':domain,'key':key,'keyLocation':f'https://{domain}/{key}.txt','urlList':sorted(urls)}
req=urllib.request.Request('https://api.indexnow.org/indexnow',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'},method='POST')
with urllib.request.urlopen(req,timeout=30) as r:
    print(r.status,r.read().decode(errors='ignore'))

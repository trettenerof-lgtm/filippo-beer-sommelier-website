# Logo Integration Plan — v1.4

## Decision
The public launch contains no photography. The only permitted visual identity image is Filippo's immutable approved master logo.

## Current state
Text wordmarks remain active as an accessible fallback. No approximation, crop, redraw or generated substitute is used.

## Master asset required
Provide the exact approved logo file, preferably transparent PNG or SVG exported from the approved master. The file must not be reconstructed from a carousel screenshot.

## Approved placements
1. Header, replacing the text wordmark.
2. Footer, replacing the text wordmark.
3. About page, once as a trust marker.
4. Optional newsletter confirmation page, at reduced size.

## Do not use
- repeated decorative logos;
- altered colours;
- distorted aspect ratio;
- redrawn or AI-generated versions;
- logo inside article content without a functional purpose.

## Technical integration
Save the master as `/assets/img/logo-fbss-master.png` or `.svg`, then replace elements marked `data-logo-mode="text-fallback"` with an image using class `brand-logo`. Preserve accessible text in `alt="Filippo Beer Sommelier"`.

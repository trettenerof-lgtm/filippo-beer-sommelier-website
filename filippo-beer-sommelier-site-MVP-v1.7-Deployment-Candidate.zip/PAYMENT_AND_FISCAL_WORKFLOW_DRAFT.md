# Payment and Fiscal Workflow — pre-launch draft

Status: **requires review by an Italian commercialista before the first paid booking**.

## Launch mode
- Keep the free introductory call.
- Keep the paid-consultation page as a request for scope and quotation.
- Do not activate an automatic checkout or recurring subscription at launch.
- Accept a payment only after written scope, price and administrative classification have been confirmed.

## Provisional payment method
Bank transfer is the simplest initial method. A hosted payment link may be introduced only after the fiscal workflow and provider account have been approved. The payment method does not determine whether the activity is occasional or habitual.

## Occasional-work document flow
For a genuinely occasional engagement:
1. written request and scope;
2. written price acceptance;
3. service performed;
4. payment traceable by bank transfer;
5. receipt for occasional self-employment, with the correct withholding treatment according to the client;
6. preservation of receipt, payment proof, expenses and client details;
7. inclusion in the annual tax return.

## Stop conditions
Stop accepting new paid work and obtain professional fiscal advice when activity becomes organised, marketed continuously, repeated or professionally habitual, regardless of revenue. The EUR 5,000 threshold must not be treated as an automatic VAT-number exemption.

## Website rule
No public claim such as “no VAT number needed below EUR 5,000” may appear on the site. No invoice wording is used while operating without a VAT number; the applicable document would be an occasional-service receipt, where legally appropriate.

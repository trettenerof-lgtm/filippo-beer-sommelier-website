# OVHcloud deployment — MVP v1.7

Upload the contents of this folder to the hosting document root, normally `/www`. The final path must be `/www/index.html`, not `/www/filippo-beer-sommelier-site/index.html`. Keep a backup of the current remote files before replacing them. After upload, test HTTPS, home page, menu, privacy, newsletter iframe, subscription flow, guide delivery and 404 handling.

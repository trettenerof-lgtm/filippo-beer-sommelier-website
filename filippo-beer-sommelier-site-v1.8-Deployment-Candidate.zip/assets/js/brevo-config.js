window.REQUIRED_CODE_ERROR_MESSAGE = "Scegli un prefisso paese";
window.LOCALE = "it";
window.EMAIL_INVALID_MESSAGE = window.SMS_INVALID_MESSAGE =
  "Controlla che l’indirizzo email sia corretto e riprova";
window.REQUIRED_ERROR_MESSAGE = "Completa questo campo.";
window.GENERIC_INVALID_MESSAGE =
  "Controlla che l’indirizzo email sia corretto e riprova";
window.INVALID_NUMBER =
  "Controlla che l’indirizzo email sia corretto e riprova";
window.INVALID_DATE = "Inserisci una data valida";
window.REQUIRED_MULTISELECT_MESSAGE = "Seleziona almeno 1 opzione";
window.translation = {
  common: {
    selectedList: "{quantity} lista selezionata",
    selectedLists: "{quantity} liste selezionate",
    selectedOption: "{quantity} selezionato",
    selectedOptions: "{quantity} selezionati",
  },
};
window.AUTOHIDE = false;

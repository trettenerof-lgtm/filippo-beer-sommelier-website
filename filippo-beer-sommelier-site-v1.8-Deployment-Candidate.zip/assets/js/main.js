(() => {
  const toggle=document.querySelector('.nav-toggle');
  const menu=document.querySelector('.nav-links');
  const closeMenu=()=>{if(!toggle||!menu)return;menu.classList.remove('open');document.body.classList.remove('menu-open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','Apri il menu');};
  if(toggle&&menu){
    toggle.addEventListener('click',()=>{const open=menu.classList.toggle('open');document.body.classList.toggle('menu-open',open);toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Chiudi il menu':'Apri il menu');});
    menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();toggle.focus();}});
    document.addEventListener('click',e=>{if(menu.classList.contains('open')&&!menu.contains(e.target)&&!toggle.contains(e.target))closeMenu();});
  }
  document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  const params=new URLSearchParams(location.search);
  const fields=['utm_source','utm_medium','utm_campaign','utm_content','utm_term'];
  document.querySelectorAll('form').forEach(form=>{
    fields.forEach(name=>{const input=form.querySelector(`[name="${name}"]`);if(input)input.value=params.get(name)||'';});
    const page=form.querySelector('[name="page_url"]'); if(page) page.value=location.href;
    const ref=form.querySelector('[name="referrer"]'); if(ref) ref.value=document.referrer||'';
  });
  document.querySelectorAll('[data-event]').forEach(el=>el.addEventListener('click',()=>window.dispatchEvent(new CustomEvent('fbss:conversion',{detail:{event:el.dataset.event,path:location.pathname}}))));
  document.querySelectorAll('a[target="_blank"]').forEach(a=>{const rel=new Set((a.rel||'').split(/\s+/).filter(Boolean));rel.add('noopener');rel.add('noreferrer');a.rel=[...rel].join(' ');});
})();
